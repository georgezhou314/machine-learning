import os,shutil
import time

while True:
	for i in range(10):
		prefix = str(int(time.time()*1e6))
		origin = str(i)+".png"
		after = str(i)+"/"+prefix+"_"+str(i)+".png"
		if os.path.exists(origin):
			shutil.move(origin,after)
			print(origin,"移动成功",after)
		time.sleep(0.05)
